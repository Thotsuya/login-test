<?php $__env->startSection('content'); ?>
    You are logged in! <br>
    Welcome <?php echo e(auth()->user()->name); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\login-test\resources\views/admin/home.blade.php ENDPATH**/ ?>